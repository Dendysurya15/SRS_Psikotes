<?php
    header('location:home/web_admin_psikotes');
?>